#include <stdio.h>
#include "scanner.h"
#include "global_variable.h"

void main(int argc, char* argv[])
{
	if(argc == 3)
	{
		printf("Start Scanning File : %s \n", argv[1]);
		scanner(argv[1], argv[2]);
	}
}