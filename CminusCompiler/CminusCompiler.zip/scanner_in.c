#include <stdio.h>
#include "symbol_check.h"
#include "global_variable.h"

void checkInComment(FILE* sourceCode, char* lookAhead, int* line, int* type)
{
	while (((*lookAhead) = fgetc(sourceCode)) != EOF)
	{
		if ((*lookAhead) == '\n')
			(*line)++;

		if ((*lookAhead) == '*')
			if (((*lookAhead) = fgetc(sourceCode)) == '/')
			{
				(*type) = typeCheck(lookAhead);
				break;
			}
	}
}

int checkInID(FILE* sourceCode, char* lookAhead, char* identifier)
{
	int i = 0;
	identifier[i] = *lookAhead;

	while (((*lookAhead) = fgetc(sourceCode)) != EOF)
	{
		if (isLetter(*lookAhead))
		{
			i++;
			identifier[i] = *lookAhead;
		}
		else
		{
			return TRUE;
		}
	}

	/* �ѱ����� ��� */
	return TRUE;
}

int checkInDigit(FILE* sourceCode, char* lookAhead, char* identifier)
{
	int i = 0;
	identifier[i] = *lookAhead;

	while (((*lookAhead) = fgetc(sourceCode)) != EOF)
	{
		if (isDigit(*lookAhead))
		{
			i++;
			identifier[i] = *lookAhead;
		}
		else
		{
			return TRUE;
		}
	}

	/* �ѱ����� ��� */
	return TRUE;
}

int checkInError(FILE* sourceCode, char* lookAhead, char* identifier)
{
	int i = 0;
	if (!strcmp(identifier, ""))
		identifier[i] = *lookAhead;

	if (typeCheck(lookAhead) != ERROR)
		return TRUE;

	while (((*lookAhead) = fgetc(sourceCode)) != EOF)
	{
		if (typeCheck(lookAhead) == ERROR)
		{
			i++;
			identifier[i] = *lookAhead;
		}
		else
		{
			return TRUE;
		}
	}

	/* �ѱ����� ��� */
	return TRUE;
}

int checkInSpecialSymbol(FILE* sourceCode, char* lookAhead, char* identifier)
{
	int i = 0;

	switch (*lookAhead)
	{
	case '+':
	case '-':
	case '*':
	case ',':
	case ';':
	case '(':
	case ')':
	case '[':
	case ']':
	case '{':
	case '}':
		identifier[i] = *lookAhead;
		return TRUE;

	case '/':
		if ((*lookAhead = fgetc(sourceCode)) == '*')
			return COMMENT; /* Comment �� ��� */
		else
		{
			identifier[i] = '/';
			return TRUE;
		}

	case '<':
	case '>':
	case '=':
		identifier[i++] = *lookAhead;
		
		if ((*lookAhead = fgetc(sourceCode)) == '=')
			identifier[i] = *lookAhead;
		
		return TRUE;

	case '!':
		identifier[i++] = *lookAhead;
		if ((*lookAhead = fgetc(sourceCode)) == '=')
		{
			identifier[i] = *lookAhead;
			return TRUE;
		}
		else
			return ERROR;

	default:
		printf("Special Symbol Error!\n");
		return FALSE;
	}
}

int checkKeyWord(char* data)
{
	int i;
	for (i = 0; i < sizeof(keyWordTable) / LENGTH_OF_KEYWORD; i++)
		if (!strcmp(data, keyWordTable[i]))
			return TRUE;
	
	return FALSE;
}

int makeToken(tokenPointer* head, char* data, int type, int line, int* count)
{
	tokenPointer temp = (*head);
	tokenPointer newToken = malloc(sizeof(token));
	(*newToken).line = line;
	(*newToken).count = (*count)++;
	strcpy((*newToken).data, data);
	(*newToken).prev = NULL;
	(*newToken).next = NULL;

	if (type == ID && checkKeyWord(data))
		(*newToken).type = KEYWORD;
	else
		(*newToken).type = type;

	memset(data, '\0', sizeof(char) * 40); /* data(identifier) �ʱ�ȭ */

	if ((*head) == NULL)
	{
		(*head) = newToken;
		return TRUE;
	}
	else
	{
		while ((*temp).next != NULL)
			temp = (*temp).next;
		
		(*temp).next = newToken;
		(*newToken).prev = temp;
		return TRUE;
	}

	return FALSE;
}